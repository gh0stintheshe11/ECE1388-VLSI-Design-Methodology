#!/usr/bin/python3
import os, time	
from playsound import playsound

"""
How to run this program in background
chmod +x check_make.py
nohup /path/to/test.py &
"""

path_to_watch = "./make"
sound_to_play = "/fs1/eecg/roman/rahulgulve/Music/Alarm-Fast-High-Pitch-B1.mp3"

print("Watching path: "+path_to_watch)
time.sleep(2)
print("I will play 11 second alarm if I see files being added/removed in 10s span")
print("Don't freak out if you hear this sound")
time.sleep(4)

for i in range(3):
	print("\rplaying example sound in "+str(3-i),end='')
	time.sleep(1)
playsound(sound_to_play)

before = dict ([(f, None) for f in os.listdir (path_to_watch)])

while 1:
  time.sleep (10)
  after = dict ([(f, None) for f in os.listdir (path_to_watch)])
  added = [f for f in after if not f in before]
  removed = [f for f in before if not f in after]
  if added: 
  	print("Added: ", ", ".join (added))
#  	playsound(sound_to_play)
  if removed:
  	print("Removed: ", ", ".join (removed))
#  	playsound(sound_to_play)
  before = after
